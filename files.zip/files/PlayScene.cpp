#include "PlayScene.h"
#include "Reticle.hpp"
#include "Clay.h"
#include "UI.h"
//#include "Tank.h"
//#include "Ground.h"
//#include "Enemy.h"
//#include "Infomation.h"
#include "Engine\\FontText.hpp"
#include "Gun.h"
#include "Engine/Image.h"

// �R���X�g���N�^
PlayScene::PlayScene(GameObject * parent)
    : GameObject(parent, "PlayScene"), hBackGround_(-1)//, ENEMY_NUM(5)
{
}

// ������
void PlayScene::Initialize()
{
    // ���e�B�N���̉摜�̃��[�h
    hBackGround_ = Image::Load("Image/pexels-jplenio-3131634.jpg");
    assert(hBackGround_ >= 0);

    //Instantiate<Tank>(this);
    //Instantiate<Ground>(this);
    Instantiate<Clay>(this);
    Instantiate<Reticle>(this);

    // �e�\���i�e�̓��e�B�N���̎q�N���X�j
    Instantiate<Gun>(this);

    Instantiate<UI>(this);

    //for (int i = 0; i < ENEMY_NUM; i++) {
    //    Instantiate<Enemy>(this);
    //}

    // Instantiate<Infomation>(this);

    text_.Initialize("Fonts/Rye-Regular.ttf", 28.0f);
}

// �X�V
void PlayScene::Update()
{
}

// �`��
void PlayScene::Draw()
{
    Image::SetTransform(hBackGround_, transform_);
    Image::Draw(hBackGround_);

    // text_.Draw(32, 32, "Yes!TakasuClinic");
    text_.Draw(32, 32, "Clay shooting");

    // �e�̎c��
    //text_.Draw(80, 80, "x %.f",UI::Bullet);
}

// �J��
void PlayScene::Release()
{
}