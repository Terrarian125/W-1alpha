#include "Clay.h"
#include "Engine/Input.h"
#include "Engine/Model.h"
#include "Engine/SceneManager.h"
#include "ImGui/imgui.h"

#include <DirectXMath.h>
using namespace DirectX;

//�R���X�g���N�^
Clay::Clay(GameObject* parent)
    :GameObject(parent, "Clay"), position_{ { 0.0f,0.0f,0.0f }, { 0.0f,0.0f,0.0f }, { 0.0f,0.0f,0.0f } }, hModel_{ (-1,-1,-1) }, On_down{ true, true, false }
{
}

//�f�X�g���N�^
Clay::~Clay()
{
}

//������
void Clay::Initialize()
{
    //���f���f�[�^�̃��[�h
    hModel_[0] = Model::Load("/Model/Dish00.fbx");
    assert(hModel_[0] >= 0);

    // �ꉞ����Ɗy�����炱����
    // === �ʒu�̃��� ===
    // (float)(rand() % 10 - 5)
    // X - 1.2�`1.2
    // Y 2.0�`3.0
    // Z - 6.5�` - 8.0

    position_[0] = { 0.0f, 3.0f, 0.0f }; // �ʒu
    rotate_[0]   = { 0.0f, 0.0f, 0.0f }; // ��]
    scale_[0]    = { 0.2f, 0.2f, 0.2f }; // �g�嗦

    position_[1] = { 0.8f, 1.0f, 0.0f }; // �ʒu
    rotate_[1]   = { 0.0f, 0.0f, 0.0f }; // ��]
    scale_[1]    = { 0.2f, 0.2f, 0.2f }; // �g�嗦

    position_[2] = { -0.4f, 0.0f, 0.2f }; // �ʒu
    rotate_[2]   = { 0.0f, 0.0f, 0.0f }; // ��]
    scale_[2]    = { 0.2f, 0.2f, 0.2f }; // �g�嗦

    //�����蔻��ǉ�
    SphereCollider* collision = new SphereCollider(XMFLOAT3(0.0f, 0.1f, 0.0f), 0.8f);
    AddCollider(collision);

    textClay_.Initialize("Fonts/Rye-Regular.ttf", 28.0f);
}

//�X�V
void Clay::Update()
{
    Move();


    // �e�̉�]�̏���w��
    {
        const float Limit_X_MAX = -12.0f, Limit_X_MIN = 12.0f;
        const float Limit_Y_MAX = 2.5f, Limit_Y_MIN = -2.5f;

        // �N���[�P
        {
            if (position_[0].x < Limit_X_MAX) position_[0].x = Limit_X_MIN; // ������E
            if (position_[0].x > Limit_X_MIN) position_[0].x = Limit_X_MAX; // �E���獶
        }

        // �N���[�Q
        {
            if (position_[1].x < Limit_X_MAX) position_[1].x = Limit_X_MIN; // ������E
            if (position_[1].x > Limit_X_MIN) position_[1].x = Limit_X_MAX; // �E���獶
            if (position_[1].y > Limit_Y_MAX) {
                On_down[1] = true; // �~����
                position_[1].y = Limit_Y_MAX; // �ォ�牺
            }
            if (position_[1].y < Limit_Y_MIN) {
                On_down[1] = false; // �㏸
                position_[1].y = Limit_Y_MIN; // �������
            }
        }

        // �N���[�R
        {
            if (position_[2].x < Limit_X_MAX) position_[2].x = Limit_X_MIN; // ������E
            if (position_[2].x > Limit_X_MIN) position_[2].x = Limit_X_MAX; // �E���獶
            if (position_[2].y > Limit_Y_MAX) {
                On_down[2] = true; // �~����
                position_[2].y = Limit_Y_MAX; // �ォ�牺
            }
            if (position_[2].y < Limit_Y_MIN) {
                On_down[2] = false; // �㏸
                position_[2].y = Limit_Y_MIN; // �������
            }
        }
    }
}

void Clay::Move()
{
    //�E����
    if (Input::IsKey(DIK_O))
    {
        //rotate_[0].x += 2.5f;
    }

    //������
    if (Input::IsKey(DIK_P))
    {
       //rotate_[0].x -= 2.5f;
       //position_[1].y -= 2.5f;
    }

    position_[0].x += 0.15f;
    rotate_[0].x += 2.5f;
    rotate_[0].y += 5.0f;

    position_[1].x -= 0.15f;
    rotate_[1].x -= 1.0f;
    if(On_down[1]) position_[1].y -= 0.02f;
    else position_[1].y += 0.02f;

    position_[2].x += 0.30f;
    if (On_down[2]) position_[2].y -= 0.5f;
    else position_[2].y += 0.5f;
}

//�`��
void Clay::Draw()
{
    // �N���[�\��
    transform_.position_ = { position_[0].x, position_[0].y, position_[0].z};   // �ʒu
    transform_.rotate_   = { rotate_[0].x, rotate_[0].y, rotate_[0].z };        // ��]
    transform_.scale_    = { scale_[0].x, scale_[0].y, scale_[0].z };           // �g�嗦
    Model::SetTransform(hModel_[0], transform_);
    Model::Draw(hModel_[0]);

    transform_.position_ = { position_[1].x, position_[1].y, position_[1].z };   // �ʒu
    transform_.rotate_ = { rotate_[1].x, rotate_[1].y, rotate_[1].z };           // ��]
    transform_.scale_ = { scale_[1].x, scale_[1].y, scale_[1].z };               // �g�嗦
    Model::SetTransform(hModel_[1], transform_);
    Model::Draw(hModel_[1]);

    transform_.position_ = { position_[2].x, position_[2].y, position_[2].z };   // �ʒu
    transform_.rotate_ = { rotate_[2].x, rotate_[2].y, rotate_[2].z };           // ��]
    transform_.scale_ = { scale_[2].x, scale_[2].y, scale_[2].z };               // �g�嗦
    Model::SetTransform(hModel_[2], transform_);
    Model::Draw(hModel_[2]);

    // ImGui (�f�o�b�N�p)
    {
        // ======= �N���[�̈ʒu���W =======
        ImGui::Begin("Clay_position");
        ImGui::InputFloat("pos.X1", &position_[0].x);
        ImGui::InputFloat("pos.Y1", &position_[0].y);
        ImGui::InputFloat("pos.Z1", &position_[0].z);
        ImGui::InputFloat("pos.X2", &position_[1].x);
        ImGui::InputFloat("pos.Y2", &position_[1].y);
        ImGui::InputFloat("pos.Z2", &position_[1].z);
        ImGui::InputFloat("pos.X3", &position_[2].x);
        ImGui::InputFloat("pos.Y3", &position_[2].y);
        ImGui::InputFloat("pos.Z3", &position_[2].z);
        ImGui::End();
    }
}

void Clay::Release()
{
}

void Clay::OnCollision(GameObject* pTarget)
{
    //�e�ɓ�������
    if (pTarget->GetObjectName() == "Bullet")
    {
        //����������
        KillMe();
    }
}
